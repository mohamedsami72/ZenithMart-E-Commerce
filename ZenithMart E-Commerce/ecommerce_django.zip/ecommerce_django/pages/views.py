from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
from products.models import Product
import json

def home(request):
    """Home page view"""
    # Get featured products
    featured_products = Product.objects.filter(
        available=True,
        rating__gte=4.0
    ).order_by('-rating', '-created_at')[:8]
    
    context = {
        'featured_products': featured_products,
    }
    
    return render(request, 'pages/home.html', context)

def contact(request):
    """Contact page view"""
    if request.method == 'POST':
        # Handle contact form submission
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')
        
        # Here you would typically save to database or send email
        # For now, we'll just return a success response
        
        return JsonResponse({
            'success': True,
            'message': 'Thank you for your message! We will get back to you soon.'
        })
    
    return render(request, 'pages/contact.html')

def about(request):
    """About page view"""
    return render(request, 'pages/about.html')

def not_found(request, exception=None):
    """Custom 404 page"""
    return render(request, 'pages/404.html', status=404)
