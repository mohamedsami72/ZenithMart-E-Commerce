
// Utilities
function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(';').shift();
}
const CSRF = getCookie('csrftoken');

function fmt(n){ return Number(n).toFixed(2); }

// Badge creation if not present
function ensureCartBadge(){
  let badge = document.getElementById('cart-count-badge');
  if(!badge){
    // Try to append to a cart link in navbar
    const nav = document.querySelector('a[href*="/cart"]') || document.querySelector('.cart-link');
    if(nav){
      badge = document.createElement('span');
      badge.id='cart-count-badge';
      badge.textContent='0';
      nav.appendChild(badge);
    }
  }
  return badge;
}

// Toast
function showToast(msg, emoji='✅'){
  const t = document.createElement('div');
  t.className = 'cart-toast';
  t.innerHTML = `<span style="font-size:18px">${emoji}</span><span>${msg}</span>`;
  document.body.appendChild(t);
  setTimeout(()=>{ t.remove(); }, 2200);
}

// Mini cart panel
function ensureMiniCart(){
  if(document.getElementById('mini-cart')) return;
  const panel = document.createElement('aside');
  panel.id = 'mini-cart';
  panel.innerHTML = `
    <header>
      <strong>عربة التسوق</strong>
      <button id="mini-cart-close" title="إغلاق" style="background:transparent;border:0;color:#e5e7eb;font-size:18px;cursor:pointer">✖</button>
    </header>
    <div class="items"></div>
    <footer>
      <div class="total"><span>الإجمالي</span> <span id="mini-cart-total">$0.00</span></div>
      <div style="margin-top:10px;display:flex;gap:8px">
        <a href="/cart/" class="btn btn-primary" style="flex:1;text-align:center">الذهاب للسلة</a>
        <button id="mini-cart-hide" class="btn" style="flex:1">متابعة التسوق</button>
      </div>
    </footer>`;
  document.body.appendChild(panel);
  panel.querySelector('#mini-cart-close').onclick = ()=> panel.classList.remove('open');
  panel.querySelector('#mini-cart-hide').onclick = ()=> panel.classList.remove('open');
}
function openMiniCart(){ ensureMiniCart(); document.getElementById('mini-cart').classList.add('open'); }
function renderMiniCart(data){
  ensureMiniCart();
  const panel = document.getElementById('mini-cart');
  const wrap = panel.querySelector('.items');
  wrap.innerHTML = '';
  data.items.forEach(it=>{
    const div = document.createElement('div');
    div.className='item';
    div.dataset.productId = it.id;
    div.innerHTML = `
      <img src="${it.image}" alt="${it.title}">
      <div>
        <div class="t">${it.title}</div>
        <div>$${fmt(it.price)} × ${it.quantity}</div>
      </div>
      <div class="q">
        <button class="dec" aria-label="تقليل">−</button>
        <span>${it.quantity}</span>
        <button class="inc" aria-label="زيادة">+</button>
      </div>`;
    wrap.appendChild(div);
  });
  panel.querySelector('#mini-cart-total').textContent = `$${fmt(data.total_price)}`;

  // Bind inc/dec
  wrap.querySelectorAll('.item .inc').forEach(btn=>{
    btn.onclick = (e)=>{
      const pid = e.target.closest('.item').dataset.productId;
      updateItem(pid, 1);
    }
  });
  wrap.querySelectorAll('.item .dec').forEach(btn=>{
    btn.onclick = (e)=>{
      const pid = e.target.closest('.item').dataset.productId;
      updateItem(pid, -1);
    }
  });
}

// API helpers
async function apiGetCart(){
  const res = await fetch('/cart/api/data/', { headers: { 'X-Requested-With':'XMLHttpRequest' } });
  if(!res.ok) throw new Error('Failed to fetch cart');
  return res.json();
}
async function apiAdd(productId, qty=1){
  const res = await fetch('/cart/add/', {
    method:'POST',
    headers: {'Content-Type':'application/json','X-CSRFToken':CSRF},
    body: JSON.stringify({ product_id: productId, quantity: qty })
  });
  if(!res.ok) throw new Error('Add failed');
  return res.json();
}
async function apiUpdate(productId, qty){
  const res = await fetch('/cart/update/', {
    method:'POST',
    headers: {'Content-Type':'application/json','X-CSRFToken':CSRF},
    body: JSON.stringify({ product_id: productId, quantity: qty })
  });
  if(!res.ok) throw new Error('Update failed');
  return res.json();
}
async function apiRemove(productId){
  const res = await fetch('/cart/remove/', {
    method:'POST',
    headers: {'Content-Type':'application/json','X-CSRFToken':CSRF},
    body: JSON.stringify({ product_id: productId })
  });
  if(!res.ok) throw new Error('Remove failed');
  return res.json();
}

// Sync UI counters
function syncBadge(count){
  const badge = ensureCartBadge();
  if(badge) badge.textContent = count;
}

// Public actions
async function refreshCartUI(openPanel=false){
  const data = await apiGetCart();
  syncBadge(data.total_items);
  renderMiniCart(data);
  if(openPanel) openMiniCart();
  // Update quantities on cart page if present
  if(document.getElementById('cart-items')){
    data.items.forEach(it=>{
      const row = document.querySelector(`.cart-item[data-product-id="${it.id}"]`);
      if(row){
        const qtyEl = row.querySelector('.quantity-value');
        const lineEl = row.querySelector('.line-total');
        if(qtyEl) qtyEl.textContent = it.quantity;
        if(lineEl) lineEl.textContent = `$${fmt(it.price * it.quantity)}`;
      }
    });
    const subtotal = document.getElementById('cart-subtotal');
    if(subtotal) subtotal.textContent = `$${fmt(data.total_price)}`;
  }
}

// Add to cart buttons
function bindAddToCart(){
  document.querySelectorAll('.add-to-cart').forEach(btn=>{
    btn.addEventListener('click', async (e)=>{
      e.preventDefault();
      const pid = btn.dataset.productId;
      const qty = Number(btn.dataset.qty || 1);
      try{
        await apiAdd(pid, qty);
        await refreshCartUI(true);
        showToast('تم إضافة المنتج إلى السلة', '🛒');
      }catch(err){
        console.error(err);
        showToast('حدث خطأ أثناء الإضافة', '⚠️');
      }
    });
  });
}

// Quantity controls on cart page
function bindCartPageControls(){
  document.querySelectorAll('.cart-item .qty-inc').forEach(b=>{
    b.onclick = async (e)=>{
      const pid = e.target.closest('.cart-item').dataset.productId;
      await updateItem(pid, 1);
    };
  });
  document.querySelectorAll('.cart-item .qty-dec').forEach(b=>{
    b.onclick = async (e)=>{
      const pid = e.target.closest('.cart-item').dataset.productId;
      await updateItem(pid, -1);
    };
  });
  document.querySelectorAll('.cart-item .remove-item').forEach(b=>{
    b.onclick = async (e)=>{
      const pid = e.target.closest('.cart-item').dataset.productId;
      await apiRemove(pid);
      // Remove row
      e.target.closest('.cart-item').remove();
      await refreshCartUI();
      showToast('تم حذف المنتج من السلة', '🗑️');
    };
  });
}

async function updateItem(pid, delta){
  // Read current qty from mini cart if available
  let newQty = null;
  const mc = document.querySelector(`#mini-cart .item[data-product-id="${pid}"] span`);
  if(mc){ newQty = Number(mc.textContent) + delta; }
  if(newQty !== null && newQty <= 0){
    await apiRemove(pid);
    await refreshCartUI();
    return;
  }
  await apiUpdate(pid, newQty ?? 1); // backend will set quantity
  await refreshCartUI();
}

// Init
document.addEventListener('DOMContentLoaded', async ()=>{
  ensureCartBadge();
  ensureMiniCart();
  bindAddToCart();
  bindCartPageControls();
  // initial sync
  try{ await refreshCartUI(); }catch(e){ console.warn('Cart API not available yet'); }
});
