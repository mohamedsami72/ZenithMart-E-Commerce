from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from products.models import Product
from .models import Cart, CartItem
import json

def get_or_create_cart(request):
    """Get or create cart for user or session"""
    if request.user.is_authenticated:
        cart, created = Cart.objects.get_or_create(user=request.user)
    else:
        if not request.session.session_key:
            request.session.create()
        cart, created = Cart.objects.get_or_create(session_key=request.session.session_key)
    return cart

def view_cart(request):
    """Display cart contents"""
    cart = get_or_create_cart(request)
    cart_items = cart.items.all()
    
    context = {
        'cart': cart,
        'cart_items': cart_items,
    }
    
    return render(request, 'cart/cart.html', context)

@require_POST
@csrf_exempt
def add_to_cart(request):
    """Add product to cart via AJAX"""
    try:
        data = json.loads(request.body)
        product_id = data.get('product_id')
        quantity = int(data.get('quantity', 1))
        
        product = get_object_or_404(Product, id=product_id, available=True)
        cart = get_or_create_cart(request)
        
        cart_item, created = CartItem.objects.get_or_create(
            cart=cart,
            product=product,
            defaults={'quantity': quantity}
        )
        
        if not created:
            cart_item.quantity += quantity
            cart_item.save()
        
        return JsonResponse({
            'success': True,
            'message': 'Product added to cart!',
            'cart_total_items': cart.total_items,
            'cart_total_price': float(cart.total_price),
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'message': str(e)
        })

@require_POST
@csrf_exempt
def update_cart_item(request):
    """Update cart item quantity via AJAX"""
    try:
        data = json.loads(request.body)
        product_id = data.get('product_id')
        quantity = int(data.get('quantity'))
        
        cart = get_or_create_cart(request)
        cart_item = get_object_or_404(CartItem, cart=cart, product_id=product_id)
        
        if quantity <= 0:
            cart_item.delete()
            message = 'Product removed from cart!'
        else:
            cart_item.quantity = quantity
            cart_item.save()
            message = 'Cart updated!'
        
        return JsonResponse({
            'success': True,
            'message': message,
            'cart_total_items': cart.total_items,
            'cart_total_price': float(cart.total_price),
            'item_total': float(cart_item.get_total_price()) if quantity > 0 else 0,
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'message': str(e)
        })

@require_POST
@csrf_exempt
def remove_from_cart(request):
    """Remove product from cart via AJAX"""
    try:
        data = json.loads(request.body)
        product_id = data.get('product_id')
        
        cart = get_or_create_cart(request)
        cart_item = get_object_or_404(CartItem, cart=cart, product_id=product_id)
        cart_item.delete()
        
        return JsonResponse({
            'success': True,
            'message': 'Product removed from cart!',
            'cart_total_items': cart.total_items,
            'cart_total_price': float(cart.total_price),
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'message': str(e)
        })

def get_cart_data(request):
    """Get cart data as JSON"""
    cart = get_or_create_cart(request)
    cart_data = {
        'items': [item.get_item_data() for item in cart.items.all()],
        'total_items': cart.total_items,
        'total_price': float(cart.total_price),
    }
    
    return JsonResponse(cart_data)
