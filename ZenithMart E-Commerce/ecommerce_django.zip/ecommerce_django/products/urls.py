from django.urls import path
from . import views

app_name = 'products'

urlpatterns = [
    path('', views.all_products, name='all_products'),
    path('category/<slug:category_slug>/', views.category_products, name='category_products'),
    path('<int:product_id>/<slug:slug>/', views.product_detail, name='product_detail'),
    path('api/popular/', views.popular_products, name='popular_products'),
    path('api/search/', views.search_products, name='search_products'),
]

