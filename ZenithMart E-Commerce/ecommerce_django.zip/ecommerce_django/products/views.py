from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from django.core.paginator import Paginator
from django.db.models import Q
from .models import Product, Category

def all_products(request):
    """Display all products with filtering and pagination"""
    products = Product.objects.filter(available=True)
    categories = Category.objects.all()
    
    # Category filtering
    category_slug = request.GET.get('category')
    if category_slug:
        category = get_object_or_404(Category, slug=category_slug)
        products = products.filter(category=category)
    
    # Search functionality
    search_query = request.GET.get('search')
    if search_query:
        products = products.filter(
            Q(title__icontains=search_query) | 
            Q(description__icontains=search_query)
        )
    
    # Pagination
    paginator = Paginator(products, 12)  # Show 12 products per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'products': page_obj,
        'categories': categories,
        'current_category': category_slug,
        'search_query': search_query,
    }
    
    return render(request, 'products/all_products.html', context)

def product_detail(request, product_id, slug):
    """Display product detail page"""
    product = get_object_or_404(Product, id=product_id, slug=slug, available=True)
    
    # Get related products from the same category
    related_products = Product.objects.filter(
        category=product.category,
        available=True
    ).exclude(id=product.id)[:4]
    
    context = {
        'product': product,
        'related_products': related_products,
    }
    
    return render(request, 'products/product_detail.html', context)

def category_products(request, category_slug):
    """Display products by category"""
    category = get_object_or_404(Category, slug=category_slug)
    products = Product.objects.filter(category=category, available=True)
    
    # Pagination
    paginator = Paginator(products, 12)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'products': page_obj,
        'category': category,
        'categories': Category.objects.all(),
    }
    
    return render(request, 'products/category_products.html', context)

def popular_products(request):
    """API endpoint to get popular products"""
    popular_products = Product.objects.filter(
        available=True,
        rating__gte=4.0
    ).order_by('-rating', '-created_at')[:8]
    
    products_data = []
    for product in popular_products:
        products_data.append({
            'id': product.id,
            'title': product.title,
            'price': float(product.price),
            'image': product.get_image_url(),
            'rating': float(product.rating),
            'url': product.get_absolute_url(),
        })
    
    return JsonResponse({'products': products_data})

def search_products(request):
    """AJAX search endpoint"""
    query = request.GET.get('q', '')
    if len(query) < 2:
        return JsonResponse({'products': []})
    
    products = Product.objects.filter(
        Q(title__icontains=query) | Q(description__icontains=query),
        available=True
    )[:10]
    
    products_data = []
    for product in products:
        products_data.append({
            'id': product.id,
            'title': product.title,
            'price': float(product.price),
            'image': product.get_image_url(),
            'url': product.get_absolute_url(),
        })
    
    return JsonResponse({'products': products_data})
